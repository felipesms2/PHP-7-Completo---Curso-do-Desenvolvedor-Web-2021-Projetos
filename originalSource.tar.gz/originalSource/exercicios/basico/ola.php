<div class="titulo">Olá PHP</div>

<h2>Exemplo A</h2>
<?php
echo 'Olá ';
echo "Mundo!";
?>

<h2>Exemplo B</h2>
<?= "Outra forma de me 'expressar'!" ?>

<?php
phpinfo();