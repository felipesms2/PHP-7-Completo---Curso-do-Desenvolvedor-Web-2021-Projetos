<?php
$variavelDeclarada = 'Apenas foi declarada';